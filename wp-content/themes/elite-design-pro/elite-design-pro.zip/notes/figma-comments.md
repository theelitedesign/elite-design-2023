# Comments

Description for this file goes here

---

## Client Comments

- ask client to send homepage video without text version

## Internal Comments

- animate footer lines
