=== ELITE Design ===

Contributors: Abu Bakar
Tags: custom-menu, full-width-template, theme-options, translation-ready
Requires at least: 5.8
Tested up to: 5.8
Stable tag: 1.0.0

A ELITE Design WordPress theme

== Description ==

This is a ELITE Design WordPress theme
